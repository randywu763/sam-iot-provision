#ifndef CERT_DEF_4_DEVICE_H
#define CERT_DEF_4_DEVICE_H

#include "atcacert/atcacert_def.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const uint8_t g_cert_template_4_device[422] ;
extern const atcacert_def_t g_cert_def_4_device ;

#ifdef __cplusplus
}
#endif

#endif // CERT_DEF_4_DEVICE_H
