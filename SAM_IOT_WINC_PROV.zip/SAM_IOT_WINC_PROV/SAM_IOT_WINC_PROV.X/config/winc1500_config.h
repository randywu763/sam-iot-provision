/* Auto-generated config file winc1500_config.h */
#ifndef WINC1500_CONFIG_H
#define WINC1500_CONFIG_H

// <<< Use Configuration Wizard in Context Menu >>>

#include <stdio.h>
// <h> Basic configuration

// <q> Enable Wi-Fi Management
// <i> Enable Wi-Fi Management
// <id> wifi_mgmt_enable
#ifndef CONF_MGMT
#define CONF_MGMT 0
#endif
#ifndef CONF_WINC_USE_SPI
#define CONF_WINC_USE_SPI 1
#endif
#ifndef CONF_PERIPH
#define CONF_PERIPH 1
#endif
#define CONF_WINC_DEBUG (1)
//#define CONF_WINC_PRINTF printf
#define CONF_WINC_PRINTF 
// </h>

// <<< end of configuration section >>>

#endif // WINC1500_CONFIG_H
